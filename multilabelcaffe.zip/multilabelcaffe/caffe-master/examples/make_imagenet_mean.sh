#!/usr/bin/env sh
# Compute the mean image from the imagenet training lmdb
# N.B. this is available in data/ilsvrc12

EXAMPLE=/home/nfd/mycaffe/multilabel/testdata
DATA=/home/nfd/mycaffe/multilabel/testdata
TOOLS=/home/nfd/mycaffe/multilabel/caffe-master/build/tools

$TOOLS/compute_image_mean $EXAMPLE/multilabel_train_lmdb \
  $DATA/multilabel_mean.binaryproto

echo "Done."
