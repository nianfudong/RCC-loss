#!/usr/bin/env sh

/home/nfd/mycaffe/multilabel/caffe-master/build/tools/caffe train \
    --solver=/home/nfd/myproject/facelandmark/nianfudong/aflw/solver.prototxt \
    --weights=/home/nfd/myproject/facelandmark/nianfudong/aflw/src/points_5_caffe_iter_1200000.caffemodel
